@extends('layouts.app')

@section('content')
<div class="container-fluid p-0">
<div class="col-md-12">

</div>
</div>
@endsection 