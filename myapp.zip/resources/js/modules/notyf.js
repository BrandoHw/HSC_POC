import { Notyf } from 'notyf';
window.Notyf = Notyf;