import select2 from "select2";
window.select2 = select2;
