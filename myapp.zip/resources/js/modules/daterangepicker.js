import daterangepicker from 'daterangepicker';
window.daterangepicker = daterangepicker;