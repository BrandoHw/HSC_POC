import Stepper from 'bs-stepper';
window.Stepper = Stepper;