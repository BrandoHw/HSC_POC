import flatpickr from 'flatpickr';
window.flatpickr = flatpickr;